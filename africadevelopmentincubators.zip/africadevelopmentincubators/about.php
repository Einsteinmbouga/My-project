<!DOCTYPE html>
<html lang="en">
  <head>
    <title>About-Africa Development Incubators</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Dosis:200,300,400,500,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Overpass:300,400,400i,600,700" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
      
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="oi oi-menu"></span> Menu
      </button>

      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
          <li class="nav-item active"><a href="about.php" class="nav-link">About</a></li>
           <li class="nav-item"><a href="donate.php" class="nav-link">Donate</a></li>
          <!--<li class="nav-item"><a href="blog.php" class="nav-link">Blog</a></li>-->
          <li class="nav-item"><a href="gallery.php" class="nav-link">Gallery</a></li>
          <li class="nav-item"><a href="event.php" class="nav-link">Events</a></li>
          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
        </ul>
      </div>
    </div>
  </nav>
    <!-- END nav -->
    
    <div class="hero-wrap" style="background-image: url('images/IMG-20200208-WA0010.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-7 ftco-animate text-center" data-scrollax=" properties: { translateY: '70%' }">
             <p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-2"><a href="index.php">Home</a></span> <span>About</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">About ADI</h1>
          </div>
        </div>
      </div>
    </div>

    
    <section class="ftco-section">
    	<div class="container">
    		<div class="row d-flex">
    			<div class="col-md-6 d-flex ftco-animate">
    				<div class="img img-about align-self-stretch" style="background-image: url(images/IMG-20200205-WA0008.jpg); width: 80%; height: 110%;"></div>
    			</div>
    			<div class="col-md-6 pl-md-5 ftco-animate">
            <h2 class="mb-4">Welcome to Africa Development Incubators</h2>
            <p>    Africa Development Incubators connects all Africans, businesses, associations 
          Governmental and non-Governmental Organzations, Actors of development and any other form of Organizations,
          <br>in every corner of the world, who are willing to participate partially or fully to the global development of Africa.<br>
          Apart from having very specific goals to achieve, we are succeeding to create an atmosphere,
          where any person willing to change Africa can have access to a new resource created called ADI.
          <br> This new resources have a huge number of benefits for everyone. </p>
           </div>
          
        </div>
       
      </div><br>
      <div class="col-md-6-mb-2" style="margin: 40px;">
        <h3>Mission</h3>
        <p>"Our Mission is to reincarnate Africa. We aspire to improve, invent or reinvent every single aspect necessary to build the Africa africans desire.<br>
         Alongside, we will thus make ADI be the natural resource accessible by everyone for a much more better Africa life."
          </p>
    </div>
    </section>

    <section class="ftco-counter ftco-intro ftco-intro-2" id="section-counter">
    	<div class="container">
        <h3><strong>Our Goal</strong> </h3>
    		<div class="row no-gutters">
          
    			<div class="col-md-5 d-flex justify-content-center counter-wrap ftco-animate">
            
            <div class="block-18 color-1 align-items-stretch">
              <div class="text">
              	<span>Sensitization</span>
                <p>
                  Africa Development Incubators sensitize the african population in several aspects of life including Engineering, Finance, Leadership, Agriculture, Entrepreneurship and Healthcare. 
                 <br> Sensitization is like a form of additional education with great aim to help maximize the power of visualization of africans.
                 <br> We believe that if a student at college visualizes deep in his heart that he or she wants to become an Engineer, then there will
                  be no need for the parent to beat the student when he is playing. Since the student will exactly have his objective in mind untill he achieve it.<br>
                  All successful people today, wether being a teacher, a doctor, an engineer, a university student, etc have achieve it due to this visualization power. <br>
                  Africa Development Incubators bring this power to every single african.<br><br>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
            <div class="block-18 color-2 align-items-stretch">
              <div class="text">
              	<h3 class="mb-4">Social projects</h3>
              	<p>
                  ADI plans, design, organize, implement and manage any form of social projects propose by any African. Beginning small, we select some social projects
                  received as proporsal and choose which project we shall implement within a specific timeframe.<br> After full execution of the project,
                  we decide all together about the next social project. As we grow, we aspire to realize multiple well coordonated projects in parallel.<br> The choice of our social projects are done in an easily understandable manner.
                  <br><br>
                </p>
              	<!--<p><a href="#" class="btn btn-white px-3 py-2 mt-2">Donate Now</a></p>-->
              </div>
            </div>
          </div>
          <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
            <div class="block-18 color-3 align-items-stretch">
              <div class="text">
              	<h3 class="mb-4">Network of Network </h3>
              	<p>
                  As Africans, we generally know the life expression: "We are someone behind someone ". 
                  As ADI, the general life expression follows: "We are someone behind everyone". ADI gives you the possibility to have access to any person you desire for your success.
                  <br> Whether you need a qualified or under qualified person for your business, you need someone a contact to a place you are heading to, you need an advisor, you need friends, you need business partners, etc. <br>
                  In fact any desire you have to achieve your goals is provided by ADI, especially when you also insert effort for the development of Africa.
                </p>
              	<!--<p><a href="#" class="btn btn-white px-3 py-2 mt-2">Be A Volunteer</a></p>-->
              </div>
            </div>
          </div>
    		</div>
    	</div>
    </section>

    <section class="ftco-section bg-light">
      <div class="container">
      	<div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section ftco-animate text-center"  >
            <h2 class="mb-4">Current members</h2>
            <p><font size="4">
              ADI is currently having about 500 direct members and 1000 indirect members with whom we work to push the development of Africa forward.
              <br> We have members coming from over 30 countries including North Korea, Mali, South Africa, Turkey, Germany, Cameroon, Usa, etc <br>
              who are all willing to strongly participate for the development of Africa. The activities we carry on with those members are to be concretely implemented in African countries including Cameroon.
              <br>
              <br> We are always happy to grow our network so as to easily achieve our objectives. We believe that when one billion Africans <br>
              insert one hour for the development of Africa, we are having one billion hours. Believe ADI, this makes us to achieve 100 years objectives within months.
              <br> Ready to Join ADI? Click <a href="contact.php">Join Us</a>
            </font></p>
           </div>
        </div>
        
      </div><br>
      <p class="text-center"><font size="4">Assist us to make life much more better for millions of africans!!!</font><p>
       <div  class="col-md-6">
        <h4>Back to Home</h4><a href="index.php">Home</a>
       </div> 

    </section>
		

    <footer class="ftco-footer ftco-section img">
    	<div class="overlay"></div>
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About Us</h2>
              <p>ADI and its members work hard to participate in developing Africa. We believe it is possible</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="https://www.youtube.com/channel/UCkhAkTNW6vtoE32Ue1rxbIw"><span class="icon-youtube"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/africadevelopmentincubator18/ "><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://www.linkedin.com/company/africa-development-incubators/?viewAsMember=true"><span class="icon-linkedin"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Recent Blog about ADI</h2>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/image_1.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="#">Even the all-powerful Pointing has no control about</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> July 12, 2018</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                    <div><a href="#"><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/image_2.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="#">Even the all-powerful Pointing has no control about</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> July 12, 2018</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                    <div><a href="#"><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-2">
             <div class="ftco-footer-widget mb-4 ml-md-4">
              <h2 class="ftco-heading-2">Important pages</h2>
              <ul class="list-unstyled">
                <li><a href="index.php" class="py-2 d-block">Home</a></li>
                <li><a href="about.php" class="py-2 d-block">About</a></li>
                <li><a href="donate.php" class="py-2 d-block">Donate</a></li>
                 <li><a href="event.php" class="py-2 d-block">Event</a></li>
                <!--<li><a href="blog.php" class="py-2 d-block">Blog</a></li>-->
              </ul>
            </div>
          </div>
          <div class="col-md-3">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Cameroon, Yaounde</span></li>
	                <li><span class="icon icon-phone"></span><span class="text">+237 98571001</span></li>
                  <br>
                  <li><span class="icon icon-map-marker"></span><span class="text">Germany</span></li>
	                <li><span class="icon icon-phone"></span><span class="text">+4915736239194</span></li>
                  <li><span class="icon icon-envelope"></span><span class="text">adincubator@gmail.com</span></li>

                </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>